//4:Famous Quote: Find a quote from a famous person you admire. Print the quote and the name of its author. Your output should look something like the following, including the quotation marks:
//Albert Einstein once said, “A person who never made a mistake never tried anything new.”
//let name1:string =("Hazrat Ali Said")
//console.log(`"${name1}, Each person's Grief Is Acording To His corage"`)
var name1 = ("Allama Iqbal Said");
console.log("\"".concat(name1, " ,Insaan ko ikhlaqi taraqqi ki buland tareen manzil us waqt haasil hoti hai jab woh khauf aur gham se mukammal tor par azad ho jata hai."));
