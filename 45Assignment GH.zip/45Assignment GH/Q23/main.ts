//23:Conditional Tests: Write a series of conditional tests. Print a statement describing each test and your prediction for the results of each test. Your code should look something like this:
//let car = 'subaru';
//console.log("Is car == 'subaru'? I predict True."console.log(car == 'subaru')
//• Look closely at your results, and make sure you understand why each line evaluates to True or False.
//• Create at least 10 tests. Have at least 5 tests evaluate to True and another 5 tests evaluate to False.

let car = 'subaru';

//console.log("Is car =='subaru'? I predict True otherwise I predict False")
console.log(car == 'subaru')
console.log(car == 'Civic')
let num: any = 23
console.log(car == 'subaru')
//console.log("Is num == 23(in number) ? I predict true otherwaise I predict False")
console.log(num ===23)
console.log(num === "23")
let name: string = 'muniba'
console.log(name === 'muniba')
console.log(name === 'muniba')
