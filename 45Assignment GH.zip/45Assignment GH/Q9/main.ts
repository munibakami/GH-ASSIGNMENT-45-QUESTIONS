//9:Favorite Number: Store your favorite number in a variable. Then, using that variable, create a message that reveals your favorite number. Print that message.

let num: number = 7439

console.log(`My Favorite Number Is ${num}`);