//19:Dinner Guests: Working with one of the programs from Exercises 14 through 18, print a message indicating the number of people you are inviting to dinner.
let guestArr: string[] = ["Tuba","Sobia","Rifat","Nuzhat","Rumesa"]

//guestArr.forEach(oneGuest => console.log(`Dear ${oneGuest}, You Are Invited To a Dinner`))

let lengthGuest: number = guestArr.length;

console.log(`We are Inviting total ${lengthGuest} guest.`);


