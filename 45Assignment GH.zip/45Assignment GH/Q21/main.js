//21:They think of something you could store in a TypeScript Object. Write a program that creates Objects containing these items.
let person = { name: "Kamran", fname: "Raees", age: 25 };
console.log(person);
export {};
