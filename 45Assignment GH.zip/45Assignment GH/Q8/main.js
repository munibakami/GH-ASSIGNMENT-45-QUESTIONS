//8:You should create four lines that look like this:
//console.log(5 + 3)
//Your output should simply be four lines with the number 8 appearing once on each line.
// 8.
console.log(5 + 3);
console.log(18 - 10);
console.log(2 * 4);
console.log(16 / 2);
export {};
