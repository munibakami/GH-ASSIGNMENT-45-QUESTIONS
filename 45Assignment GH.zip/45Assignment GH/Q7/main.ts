//7:Number Eight: Write addition, subtraction, multiplication, and division operations that each result in the number 8. Be sure to enclose your operations in print statements to see the results.

console.log(4 + 4);
console.log(12 - 4);
console.log(4 * 2);
console.log(16 / 2);
console.log(16 % 2);

