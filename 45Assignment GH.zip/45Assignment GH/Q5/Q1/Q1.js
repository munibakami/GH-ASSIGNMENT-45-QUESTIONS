//1:Install Node.js, TypeScript and VS Code on your computer.
export {};
