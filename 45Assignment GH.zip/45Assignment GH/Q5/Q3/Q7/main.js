//7:Number Eight: Write addition, subtraction, multiplication, and division operations that each result in the number 8. Be sure to enclose your operations in print statements to see the results.
let a = 10;
let b = 5;
//Addition
console.log(a + b);
//subtraction
console.log(a - b);
//multiplication
console.log(a * b);
//division
console.log(a / b);
export {};
