//5:Famous Quote 2: Repeat Exercise 4, but this time store the famous person’s name in a variable called famous_person. Then compose your message and store it in a new variable called message. Print your message.
let famous_person = "Hazrat Ali";
let message = "Accept The Apology,Even It Is Not Sincer";
console.log(`${famous_person} Once Said, "${message}"`);
export {};
