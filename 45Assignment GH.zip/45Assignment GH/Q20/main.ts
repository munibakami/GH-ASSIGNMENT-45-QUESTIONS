//Think of something you could store in a array. For example, you could make a list of mountains, rivers, countries, cities, languages, or anything else you’d like. Write a program that creates a list containing these items.

//making a programing languages array
let programingLanguages: string[] = ["Typescript","JavaScript","Python","PHP"];

      console.log("List Of Programing Languages:");

programingLanguages.forEach(language => console.log(language));



